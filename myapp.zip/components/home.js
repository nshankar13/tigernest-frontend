import React from 'react'

const Home = () => (
  <div>
    <h1>Welcome to TigerNest!</h1>
  </div>
)

export default Home
