export default () => (
  <div>This is the Events page.</div>
)
